import 'package:flutter/material.dart';
import 'job_store.dart';
import 'persistence.dart';

const ink = Color(0xFF172D3A),
    muted = Color(0xFF61727A),
    paper = Color(0xFFF4F4EF),
    line = Color(0xFFE1E6E4),
    accent = Color(0xFFEBC96B),
    teal = Color(0xFF287D72);
void main() {
  runApp(FieldnoteApp(store: JobStore(createLocalStore())));
}

class FieldnoteApp extends StatelessWidget {
  final JobStore store;
  const FieldnoteApp({super.key, required this.store});
  @override
  Widget build(BuildContext context) => MaterialApp(
      title: 'Fieldnote · Flutter demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: paper,
          colorScheme: ColorScheme.fromSeed(
              seedColor: teal, primary: ink, surface: Colors.white),
          fontFamily: 'FieldnoteSans',
          textTheme: const TextTheme(
              bodyMedium: TextStyle(color: ink, fontSize: 14, height: 1.45),
              bodySmall: TextStyle(color: muted, fontSize: 12, height: 1.4)),
          inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: line)),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: line))),
          filledButtonTheme: FilledButtonThemeData(
              style: FilledButton.styleFrom(
                  minimumSize: const Size(48, 48),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12))))),
      home: Workspace(store: store));
}

class Workspace extends StatefulWidget {
  final JobStore store;
  const Workspace({super.key, required this.store});
  @override
  State<Workspace> createState() => _WorkspaceState();
}

class _WorkspaceState extends State<Workspace> {
  String query = '', selected = 'FN-1042';
  JobStatus? filter;
  final search = TextEditingController();
  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  void showJob(Job job, bool wide) {
    setState(() => selected = job.id);
    if (!wide)
      showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          useSafeArea: true,
          backgroundColor: paper,
          builder: (c) => FractionallySizedBox(
              heightFactor: .94,
              child: ListenableBuilder(
                  listenable: widget.store,
                  builder: (c, _) => JobDetail(
                      job: widget.store.jobs.firstWhere((j) => j.id == job.id),
                      store: widget.store,
                      onClose: () => Navigator.pop(c)))));
  }

  Future<void> reset() async {
    final yes = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
                title: const Text('Reset this demo?'),
                content: const Text(
                    'This replaces your demo notes and status changes with the original sample jobs. It only affects this browser.'),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(c, false),
                      child: const Text('Keep changes')),
                  FilledButton(
                      onPressed: () => Navigator.pop(c, true),
                      child: const Text('Reset sample data'))
                ]));
    if (yes == true) {
      widget.store.reset();
      setState(() {
        query = '';
        filter = null;
        selected = 'FN-1042';
        search.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: widget.store,
      builder: (context, _) => LayoutBuilder(builder: (context, box) {
            final wide = box.maxWidth >= 1060;
            final roomy = box.maxWidth >= 700;
            final store = widget.store,
                visible = widget.store.filtered(query: query, status: filter);
            final done =
                store.jobs.where((j) => j.status == JobStatus.complete).length;
            return Scaffold(
                body: SafeArea(
                    child: Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                  if (wide)
                    Container(
                        width: 204,
                        color: ink,
                        padding: const EdgeInsets.all(24),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 10),
                              const Icon(Icons.layers_rounded,
                                  color: accent, size: 35),
                              const SizedBox(height: 14),
                              const Text('fieldnote',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 27,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: -1)),
                              const SizedBox(height: 4),
                              const Text('GOOD WORK, IN ORDER.',
                                  style: TextStyle(
                                      color: Color(0xFFAFBFBE),
                                      fontSize: 9,
                                      letterSpacing: 1.3)),
                              const SizedBox(height: 48),
                              Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 14),
                                  decoration: BoxDecoration(
                                      color:
                                          Colors.white.withValues(alpha: .10),
                                      borderRadius: BorderRadius.circular(12)),
                                  child: const Row(children: [
                                    Icon(Icons.view_agenda_outlined,
                                        color: accent, size: 19),
                                    SizedBox(width: 10),
                                    Text('Work orders',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w600))
                                  ])),
                              const Spacer(),
                              const Icon(Icons.flutter_dash, color: accent),
                              const SizedBox(height: 12),
                              const Text('Built with Flutter',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600)),
                              const SizedBox(height: 6),
                              const Text(
                                  'An independent portfolio concept by Kish.',
                                  style: TextStyle(
                                      color: Color(0xFFAFBFBE),
                                      fontSize: 12,
                                      height: 1.6)),
                              const SizedBox(height: 24),
                              const Text('SYNTHETIC DATA ONLY',
                                  style: TextStyle(
                                      color: accent,
                                      fontSize: 9,
                                      letterSpacing: 1.1)),
                            ])),
                  Expanded(
                      child: CustomScrollView(slivers: [
                    SliverToBoxAdapter(
                        child: Padding(
                            padding: EdgeInsets.fromLTRB(
                                roomy ? 32 : 20, 24, roomy ? 32 : 20, 16),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(children: [
                                    if (!wide) ...[
                                      const Icon(Icons.layers_rounded,
                                          color: ink, size: 26),
                                      const SizedBox(width: 8),
                                      const Text('fieldnote',
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w800,
                                              letterSpacing: -.8)),
                                      const Spacer()
                                    ] else ...[
                                      const Text('WORKSPACE / WORK ORDERS',
                                          style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: muted,
                                              letterSpacing: 1.2)),
                                      const Spacer()
                                    ],
                                    const DemoPill(),
                                    const SizedBox(width: 8),
                                    IconButton(
                                        tooltip: 'About this demo',
                                        onPressed: () => showDialog(
                                            context: context,
                                            builder: (c) => AlertDialog(
                                                    title: const Text(
                                                        'A small app. Real interactions.'),
                                                    content: const Text('Fieldnote is an independent Flutter portfolio concept by Kish. Every job, location, and person is fictional.\n\nTry searching, filtering, changing job status, and saving a note. Changes stay in this browser when storage is available. There is no backend, login, analytics, or live customer data.\n\nPlease use sample notes only. This is not a production service.'),
                                                    actions: [
                                                      TextButton(
                                                          onPressed: () =>
                                                              Navigator.pop(c),
                                                          child: const Text(
                                                              'Got it'))
                                                    ])),
                                        icon: const Icon(Icons.info_outline,
                                            size: 20))
                                  ]),
                                  const SizedBox(height: 26),
                                  Container(
                                      width: double.infinity,
                                      padding: EdgeInsets.all(roomy ? 28 : 22),
                                      decoration: BoxDecoration(
                                          color: ink,
                                          borderRadius:
                                              BorderRadius.circular(22)),
                                      child: Row(children: [
                                        Expanded(
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                              const Text('THE DAILY LINEUP',
                                                  style: TextStyle(
                                                      color: accent,
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      letterSpacing: 1.7)),
                                              const SizedBox(height: 10),
                                              Text(
                                                  'Every job.\nA little more together.',
                                                  style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: roomy ? 35 : 29,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      height: 1.1,
                                                      letterSpacing: -1)),
                                              const SizedBox(height: 14),
                                              const Text(
                                                  'A calm workspace for hands-on teams.',
                                                  style: TextStyle(
                                                      color: Color(0xFFBCCBCD),
                                                      fontSize: 13)),
                                              const SizedBox(height: 20),
                                              Wrap(
                                                  spacing: 8,
                                                  runSpacing: 8,
                                                  children: [
                                                    const SmallTag(
                                                        text:
                                                            'Sample day · Tuesday',
                                                        dark: true),
                                                    SmallTag(
                                                        text:
                                                            '$done of ${store.jobs.length} complete',
                                                        dark: true)
                                                  ])
                                            ])),
                                        if (roomy) ...[
                                          const SizedBox(width: 18),
                                          SizedBox(
                                              width: 100,
                                              height: 100,
                                              child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    SizedBox(
                                                        width: 95,
                                                        height: 95,
                                                        child: CircularProgressIndicator(
                                                            value: done /
                                                                store.jobs
                                                                    .length,
                                                            strokeWidth: 7,
                                                            backgroundColor:
                                                                Colors
                                                                    .white
                                                                    .withValues(
                                                                        alpha:
                                                                            .12),
                                                            color: accent)),
                                                    Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Text(
                                                              '${(done / store.jobs.length * 100).round()}%',
                                                              style: const TextStyle(
                                                                  fontSize: 24,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                  color: Colors
                                                                      .white)),
                                                          const Text('COMPLETE',
                                                              style: TextStyle(
                                                                  fontSize: 8,
                                                                  letterSpacing:
                                                                      1.3,
                                                                  color: Color(
                                                                      0xFFBCCBCD)))
                                                        ])
                                                  ]))
                                        ]
                                      ])),
                                  const SizedBox(height: 22),
                                  Row(children: [
                                    for (final s in JobStatus.values) ...[
                                      Expanded(
                                          child: Metric(
                                              label: s.label,
                                              value: store.jobs
                                                  .where((j) => j.status == s)
                                                  .length,
                                              color: statusColor(s))),
                                      if (s != JobStatus.complete)
                                        const SizedBox(width: 10)
                                    ]
                                  ]),
                                  const SizedBox(height: 28),
                                  Row(children: [
                                    const Text('Work orders',
                                        style: TextStyle(
                                            fontSize: 23,
                                            fontWeight: FontWeight.w700,
                                            letterSpacing: -.6)),
                                    const Spacer(),
                                    TextButton.icon(
                                        onPressed: reset,
                                        icon:
                                            const Icon(Icons.refresh, size: 17),
                                        label: const Text('Reset demo'))
                                  ]),
                                  const SizedBox(height: 12),
                                  TextField(
                                      controller: search,
                                      onChanged: (v) =>
                                          setState(() => query = v),
                                      decoration: InputDecoration(
                                          hintText:
                                              'Search jobs, places, or people',
                                          prefixIcon: const Icon(Icons.search,
                                              size: 21),
                                          suffixIcon: query.isEmpty
                                              ? null
                                              : IconButton(
                                                  tooltip: 'Clear search',
                                                  onPressed: () {
                                                    search.clear();
                                                    setState(() => query = '');
                                                  },
                                                  icon: const Icon(Icons.close,
                                                      size: 19)))),
                                  const SizedBox(height: 12),
                                  SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Row(children: [
                                        FilterChip(
                                            label: Text(
                                                'All jobs (${store.jobs.length})'),
                                            selected: filter == null,
                                            onSelected: (_) =>
                                                setState(() => filter = null)),
                                        const SizedBox(width: 8),
                                        for (final s in JobStatus.values) ...[
                                          FilterChip(
                                              label: Text(s.label),
                                              selected: filter == s,
                                              onSelected: (_) =>
                                                  setState(() => filter = s)),
                                          const SizedBox(width: 8)
                                        ]
                                      ])),
                                  const SizedBox(height: 14),
                                  Text(
                                      '${visible.length} ${visible.length == 1 ? 'job' : 'jobs'} shown · Tap a job to manage it',
                                      style: const TextStyle(
                                          color: muted, fontSize: 12)),
                                ]))),
                    if (visible.isEmpty)
                      SliverToBoxAdapter(
                          child: Padding(
                              padding: const EdgeInsets.all(32),
                              child: Column(children: [
                                const Icon(Icons.search_off,
                                    size: 42, color: muted),
                                const SizedBox(height: 12),
                                const Text('No jobs match just yet.',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18)),
                                const SizedBox(height: 6),
                                const Text(
                                    'Try a different search or clear your filters.'),
                                const SizedBox(height: 10),
                                TextButton(
                                    onPressed: () {
                                      search.clear();
                                      setState(() {
                                        query = '';
                                        filter = null;
                                      });
                                    },
                                    child: const Text('Show all jobs'))
                              ])))
                    else
                      SliverPadding(
                          padding:
                              EdgeInsets.symmetric(horizontal: roomy ? 32 : 20),
                          sliver: SliverList.builder(
                              itemCount: visible.length,
                              itemBuilder: (context, i) => Padding(
                                  padding: const EdgeInsets.only(bottom: 10),
                                  child: JobCard(
                                      job: visible[i],
                                      selected:
                                          wide && selected == visible[i].id,
                                      onTap: () =>
                                          showJob(visible[i], wide))))),
                    SliverToBoxAdapter(
                        child: Padding(
                            padding: EdgeInsets.fromLTRB(
                                roomy ? 32 : 20, 16, 20, 30),
                            child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(
                                      store.persistent
                                          ? Icons.lock_outline
                                          : Icons.warning_amber,
                                      size: 15,
                                      color: muted),
                                  const SizedBox(width: 6),
                                  Expanded(
                                      child: Text(
                                          store.persistent
                                              ? 'Demo changes stay in this browser. Use sample notes only.'
                                              : 'Browser storage is unavailable. Changes may not survive a refresh.',
                                          style: const TextStyle(
                                              fontSize: 11, color: muted)))
                                ])))
                  ])),
                  if (wide)
                    Container(
                        width: 370,
                        decoration: const BoxDecoration(
                            color: Colors.white,
                            border: Border(left: BorderSide(color: line))),
                        child: JobDetail(
                            job: store.jobs.firstWhere((j) => j.id == selected),
                            store: store)),
                ])));
          }));
}

Color statusColor(JobStatus s) => switch (s) {
      JobStatus.scheduled => const Color(0xFF657C97),
      JobStatus.active => const Color(0xFF9D6B17),
      JobStatus.complete => teal
    };
IconData categoryIcon(String c) => switch (c) {
      'Cooling' => Icons.ac_unit_rounded,
      'Electrical' => Icons.bolt_rounded,
      'Plumbing' => Icons.water_drop_outlined,
      _ => Icons.handyman_outlined
    };

class DemoPill extends StatelessWidget {
  const DemoPill({super.key});
  @override
  Widget build(BuildContext context) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
          color: accent.withValues(alpha: .25),
          borderRadius: BorderRadius.circular(6)),
      child: const Text('FLUTTER DEMO',
          style: TextStyle(
              fontSize: 9,
              letterSpacing: 1,
              fontWeight: FontWeight.w800,
              color: ink)));
}

class SmallTag extends StatelessWidget {
  final String text;
  final bool dark;
  const SmallTag({super.key, required this.text, this.dark = false});
  @override
  Widget build(BuildContext context) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
          color: dark ? Colors.white.withValues(alpha: .08) : paper,
          borderRadius: BorderRadius.circular(6)),
      child: Text(text,
          style: TextStyle(color: dark ? Colors.white : muted, fontSize: 11)));
}

class Metric extends StatelessWidget {
  final String label;
  final int value;
  final Color color;
  const Metric(
      {super.key,
      required this.label,
      required this.value,
      required this.color});
  @override
  Widget build(BuildContext context) => Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: line)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 7),
          Text('$value',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700))
        ]),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 11, color: muted))
      ]));
}

class JobCard extends StatelessWidget {
  final Job job;
  final bool selected;
  final VoidCallback onTap;
  const JobCard(
      {super.key,
      required this.job,
      required this.selected,
      required this.onTap});
  @override
  Widget build(BuildContext context) => Material(
      color: Colors.white,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(
              color: selected ? teal : line, width: selected ? 1.5 : 1)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
          onTap: onTap,
          child: Padding(
              padding: const EdgeInsets.all(17),
              child:
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                        color: paper, borderRadius: BorderRadius.circular(11)),
                    child:
                        Icon(categoryIcon(job.category), size: 23, color: ink)),
                const SizedBox(width: 13),
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Wrap(
                          spacing: 7,
                          runSpacing: 3,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Text('${job.time} · ${job.duration}',
                                style: const TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                    color: muted)),
                            if (job.urgent)
                              const Text('PRIORITY',
                                  style: TextStyle(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xFF9D6B17)))
                          ]),
                      const SizedBox(height: 5),
                      Text(job.title,
                          style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                              letterSpacing: -.3)),
                      const SizedBox(height: 3),
                      Text(job.location,
                          style: const TextStyle(fontSize: 12, color: muted)),
                      const SizedBox(height: 10),
                      Row(children: [
                        Container(
                            width: 5,
                            height: 5,
                            decoration: BoxDecoration(
                                color: statusColor(job.status),
                                shape: BoxShape.circle)),
                        const SizedBox(width: 6),
                        Text(job.status.label,
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: statusColor(job.status))),
                        const Spacer(),
                        Text(job.id,
                            style: const TextStyle(fontSize: 10, color: muted))
                      ])
                    ])),
                const SizedBox(width: 7),
                const Icon(Icons.chevron_right, color: muted, size: 20)
              ]))));
}

class JobDetail extends StatefulWidget {
  final Job job;
  final JobStore store;
  final VoidCallback? onClose;
  const JobDetail(
      {super.key, required this.job, required this.store, this.onClose});
  @override
  State<JobDetail> createState() => _JobDetailState();
}

class _JobDetailState extends State<JobDetail> {
  final note = TextEditingController();
  @override
  void didUpdateWidget(covariant JobDetail oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.job.id != widget.job.id) note.clear();
  }

  @override
  void dispose() {
    note.dispose();
    super.dispose();
  }

  void saveNote() {
    if (widget.store.addNote(widget.job.id, note.text)) {
      note.clear();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Sample note added'), duration: Duration(seconds: 2)));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              'Add a note of 1–500 characters. Maximum 50 notes per job.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final j = widget.job;
    return SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(
            25, 25, 25, 25 + MediaQuery.viewInsetsOf(context).bottom),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Text('JOB DETAILS',
                style: TextStyle(
                    color: muted,
                    fontSize: 10,
                    letterSpacing: 1.3,
                    fontWeight: FontWeight.w700)),
            const Spacer(),
            if (widget.onClose != null)
              IconButton(
                  tooltip: 'Close job details',
                  onPressed: widget.onClose,
                  icon: const Icon(Icons.close))
            else
              const Icon(Icons.north_east, size: 17, color: muted)
          ]),
          const SizedBox(height: 30),
          Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                  color: accent.withValues(alpha: .28),
                  borderRadius: BorderRadius.circular(16)),
              child: Icon(categoryIcon(j.category), size: 30, color: ink)),
          const SizedBox(height: 20),
          Text(j.id,
              style: const TextStyle(
                  fontSize: 11,
                  color: muted,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1)),
          const SizedBox(height: 7),
          Text(j.title,
              style: const TextStyle(
                  fontSize: 29,
                  fontWeight: FontWeight.w700,
                  height: 1.1,
                  letterSpacing: -.8)),
          const SizedBox(height: 9),
          Text(j.location, style: const TextStyle(color: muted)),
          const SizedBox(height: 18),
          Wrap(spacing: 7, runSpacing: 7, children: [
            SmallTag(text: j.category),
            if (j.urgent) const SmallTag(text: 'Priority visit'),
            const SmallTag(text: 'Sample job')
          ]),
          const SizedBox(height: 24),
          const Divider(color: line),
          const SizedBox(height: 17),
          _detailRow(
              Icons.schedule, 'Arrival window', '${j.time} · ${j.duration}'),
          const SizedBox(height: 16),
          _detailRow(Icons.person_outline, 'Assigned to', j.technician),
          const SizedBox(height: 23),
          const Text('The brief',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 8),
          Text(j.description,
              style: const TextStyle(color: muted, fontSize: 13, height: 1.7)),
          const SizedBox(height: 24),
          DropdownButtonFormField<JobStatus>(
              key: ValueKey('${j.id}-${j.status}'),
              initialValue: j.status,
              decoration: const InputDecoration(
                  labelText: 'Job status',
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 14, vertical: 12)),
              items: JobStatus.values
                  .map((s) => DropdownMenuItem(value: s, child: Text(s.label)))
                  .toList(),
              onChanged: (s) {
                if (s != null) widget.store.transition(j.id, s);
              }),
          const SizedBox(height: 12),
          if (j.status != JobStatus.complete)
            SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                    onPressed: () => widget.store.transition(
                        j.id,
                        j.status == JobStatus.scheduled
                            ? JobStatus.active
                            : JobStatus.complete),
                    icon: Icon(
                        j.status == JobStatus.scheduled
                            ? Icons.play_arrow_rounded
                            : Icons.check_rounded,
                        size: 20),
                    label: Text(j.status == JobStatus.scheduled
                        ? 'Start this job'
                        : 'Mark complete')))
          else
            Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                    color: teal.withValues(alpha: .08),
                    borderRadius: BorderRadius.circular(12)),
                child: const Row(children: [
                  Icon(Icons.check_circle_outline, color: teal, size: 20),
                  SizedBox(width: 10),
                  Text('Good work. This one is complete.',
                      style: TextStyle(
                          color: teal,
                          fontSize: 12,
                          fontWeight: FontWeight.w600))
                ])),
          const SizedBox(height: 27),
          Row(children: [
            const Text('Field notes',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const Spacer(),
            Text('${j.notes.length}', style: const TextStyle(color: muted))
          ]),
          const SizedBox(height: 12),
          if (j.notes.isEmpty)
            const Padding(
                padding: EdgeInsets.only(bottom: 16),
                child: Text(
                    'No notes yet. Leave the next person a helpful update.',
                    style: TextStyle(color: muted, fontSize: 12))),
          for (final n in j.notes)
            Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                    color: paper, borderRadius: BorderRadius.circular(10)),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('DEMO NOTE',
                          style: TextStyle(
                              fontSize: 8,
                              color: muted,
                              letterSpacing: 1,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 5),
                      Text(n, style: const TextStyle(fontSize: 12, height: 1.6))
                    ])),
          TextField(
              controller: note,
              maxLength: 500,
              minLines: 3,
              maxLines: 5,
              decoration: const InputDecoration(
                  hintText: 'Add a sample work note…',
                  helperText: 'Stored in this browser. No personal details.',
                  helperMaxLines: 2)),
          const SizedBox(height: 4),
          Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                  onPressed: saveNote,
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Save note'))),
          const SizedBox(height: 20),
          const Text('Independent portfolio concept · No client affiliation',
              style: TextStyle(color: muted, fontSize: 10, height: 1.5)),
        ]));
  }

  Widget _detailRow(IconData icon, String label, String value) =>
      Row(children: [
        Icon(icon, color: muted, size: 20),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: muted, fontSize: 10)),
          const SizedBox(height: 3),
          Text(value,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))
        ])
      ]);
}
