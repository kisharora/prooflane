import 'job_store.dart';

LocalStore createLocalStore() => MemoryStore();
