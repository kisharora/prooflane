import 'dart:js_interop';
import 'job_store.dart';

@JS('localStorage.getItem')
external JSString? _getItem(JSString key);
@JS('localStorage.setItem')
external void _setItem(JSString key, JSString value);

class BrowserStore implements LocalStore {
  @override
  String? read() => _getItem('fieldnote-demo-v1'.toJS)?.toDart;
  @override
  void write(String value) => _setItem('fieldnote-demo-v1'.toJS, value.toJS);
}

LocalStore createLocalStore() => BrowserStore();
