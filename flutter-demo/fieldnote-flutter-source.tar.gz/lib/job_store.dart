import 'dart:convert';
import 'package:flutter/foundation.dart';

enum JobStatus { scheduled, active, complete }

extension StatusLabel on JobStatus {
  String get label => switch (this) {
        JobStatus.scheduled => 'Scheduled',
        JobStatus.active => 'In progress',
        JobStatus.complete => 'Complete'
      };
}

abstract class LocalStore {
  String? read();
  void write(String value);
}

class MemoryStore implements LocalStore {
  String? value;
  @override
  String? read() => value;
  @override
  void write(String value) => this.value = value;
}

class Job {
  final String id,
      title,
      location,
      time,
      duration,
      category,
      technician,
      description;
  final bool urgent;
  JobStatus status;
  final List<String> notes;
  Job(
      {required this.id,
      required this.title,
      required this.location,
      required this.time,
      required this.duration,
      required this.category,
      required this.technician,
      required this.description,
      this.urgent = false,
      this.status = JobStatus.scheduled,
      List<String>? notes})
      : notes = notes ?? [];
}

List<Job> sampleJobs() => [
      Job(
          id: 'FN-1042',
          title: 'Restore the cool',
          location: 'Maple House · Unit 04',
          time: '09:00',
          duration: '60 min',
          category: 'Cooling',
          technician: 'Alex Morgan',
          urgent: true,
          status: JobStatus.active,
          description:
              'Inspect the living-room air conditioning unit. Check airflow, clean the filter, and confirm a steady operating temperature.',
          notes: ['Filter inspection complete. Airflow needs a second check.']),
      Job(
          id: 'FN-1043',
          title: 'A brighter welcome',
          location: 'Cedar Studio · Lobby',
          time: '10:30',
          duration: '45 min',
          category: 'Electrical',
          technician: 'Sam Rivera',
          description:
              'Replace the entry light fixture and test the switch. The sample property manager has left access instructions at reception.'),
      Job(
          id: 'FN-1044',
          title: 'Stop the drip',
          location: 'Birch Court · Unit 12',
          time: '11:30',
          duration: '45 min',
          category: 'Plumbing',
          technician: 'Alex Morgan',
          urgent: true,
          description:
              'Inspect the kitchen faucet and replace the worn washer. Check for leaks after restoring water pressure.'),
      Job(
          id: 'FN-1045',
          title: 'Ready for the season',
          location: 'Willow Place · Courtyard',
          time: '13:00',
          duration: '90 min',
          category: 'Maintenance',
          technician: 'Sam Rivera',
          description:
              'Complete the seasonal outdoor maintenance checklist. Inspect the gate, seating, and irrigation timer.'),
      Job(
          id: 'FN-1046',
          title: 'Smooth arrivals',
          location: 'Oak Workshop · Entry',
          time: '14:30',
          duration: '30 min',
          category: 'Maintenance',
          technician: 'Alex Morgan',
          status: JobStatus.complete,
          description:
              'Adjust the entry door closer and lubricate hinges. Verify that the door closes smoothly.',
          notes: [
            'Hinges serviced and closing speed adjusted. Final check passed.'
          ]),
    ];

class JobStore extends ChangeNotifier {
  final LocalStore storage;
  List<Job> jobs = sampleJobs();
  bool persistent = true;
  JobStore(this.storage) {
    _load();
  }
  void _load() {
    try {
      final raw = storage.read();
      if (raw == null) return;
      final data = jsonDecode(raw);
      if (data is! Map || data['version'] != 1 || data['jobs'] is! Map) return;
      for (final job in jobs) {
        final saved = data['jobs'][job.id];
        if (saved is! Map) continue;
        final status = saved['status'];
        if (status is String) {
          job.status = JobStatus.values
              .firstWhere((s) => s.name == status, orElse: () => job.status);
        }
        final notes = saved['notes'];
        if (notes is List &&
            notes.every((n) => n is String && n.length <= 500) &&
            notes.length <= 50) {
          job.notes
            ..clear()
            ..addAll(notes.cast<String>());
        }
      }
    } catch (_) {
      persistent = false;
    }
  }

  void _save() {
    try {
      storage.write(jsonEncode({
        'version': 1,
        'jobs': {
          for (final j in jobs)
            j.id: {'status': j.status.name, 'notes': j.notes}
        }
      }));
      persistent = true;
    } catch (_) {
      persistent = false;
    }
    notifyListeners();
  }

  bool transition(String id, JobStatus target) {
    final job = jobs.where((j) => j.id == id).firstOrNull;
    if (job == null || job.status == target) return false;
    job.status = target;
    _save();
    return true;
  }

  bool addNote(String id, String text) {
    final job = jobs.where((j) => j.id == id).firstOrNull;
    final note = text.trim();
    if (job == null ||
        note.isEmpty ||
        note.length > 500 ||
        job.notes.length >= 50) return false;
    job.notes.add(note);
    _save();
    return true;
  }

  void reset() {
    jobs = sampleJobs();
    _save();
  }

  List<Job> filtered({String query = '', JobStatus? status}) => jobs
      .where((j) =>
          (status == null || j.status == status) &&
          '${j.id} ${j.title} ${j.location} ${j.category} ${j.technician}'
              .toLowerCase()
              .contains(query.toLowerCase().trim()))
      .toList();
}
