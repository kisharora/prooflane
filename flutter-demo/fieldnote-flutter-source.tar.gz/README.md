# Fieldnote

An independent, mobile-first Flutter portfolio concept by Kish. A calm work-order app for an entirely fictional field-service team.

## Try it

- Search by job, property, technician, or category.
- Filter scheduled, in-progress, and completed work.
- Open a work order; start, complete, or reopen it.
- Add a sample field note and refresh to check browser-local persistence.
- Reset the sample data after a confirmation dialog.

Everything is synthetic. There is no client affiliation, backend, authentication, analytics, payment flow, or real customer data. Please use sample notes only. This is a demonstration, not a production field-service system.

## Implementation

- Flutter 3.47.6 / Dart 3.13.5
- Responsive split-view on wide screens and job-detail sheet on phones
- ChangeNotifier-backed state with a separate, testable storage abstraction
- Browser localStorage accessed through Dart JS interop
- Schema-aware restoration, note length/count validation, storage-failure feedback
- Locally bundled Roboto and Material icons; bundled CanvasKit web renderer

Only status and note changes are saved, under `fieldnote-demo-v1`. State is browser-specific and can disappear if site data is cleared. No data is transmitted by the application. Normal static hosting request logs are governed by the hosting provider.

## Run and build

With Flutter stable installed:

```sh
flutter pub get
flutter analyze
flutter test
flutter run -d chrome
flutter build web --release --base-href /prooflane/flutter-demo/
```

Host the contents of `build/web` at `/prooflane/flutter-demo/`. The base path must be updated if hosting elsewhere. This uses the standard JavaScript web build for static-host compatibility.

Tests cover filtering, status transitions, persisted reconstruction, reset, corrupt/unsupported storage, storage failures, note limits, the mobile interaction path, and responsive layouts at 320, 390, 768, 1060, and 1440 logical pixels. Golden screenshots are Flutter test renders, not browser screenshots.

## Structure

- `lib/job_store.dart`: model, sample data, state, validation and serialization
- `lib/persistence_web.dart`: browser-only persistence adapter
- `lib/main.dart`: responsive interface
- `test/`: unit, widget and golden tests
- `web/`: static loader and Flutter bootstrap

Roboto license is included in `assets/fonts/Roboto_LICENSE.txt`. Other Flutter runtime licensing is emitted with the build.
