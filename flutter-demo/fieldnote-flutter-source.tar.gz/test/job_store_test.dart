import 'package:flutter_test/flutter_test.dart';
import 'package:fieldnote_demo/job_store.dart';

class BrokenStore implements LocalStore {
  @override
  String? read() => throw StateError('blocked');
  @override
  void write(String value) => throw StateError('blocked');
}

void main() {
  test('sample list and combined filters', () {
    final s = JobStore(MemoryStore());
    expect(s.jobs.length, 5);
    expect(s.filtered(status: JobStatus.scheduled).length, 3);
    expect(s.filtered(query: '  BIRCH ').single.id, 'FN-1044');
    expect(s.filtered(query: 'Birch', status: JobStatus.complete), isEmpty);
  });
  test('status transitions persist and restore', () {
    final p = MemoryStore();
    final s = JobStore(p);
    expect(s.transition('FN-1043', JobStatus.active), true);
    expect(s.transition('FN-1043', JobStatus.complete), true);
    expect(s.transition('missing', JobStatus.complete), false);
    expect(s.transition('FN-1043', JobStatus.complete), false);
    expect(JobStore(p).jobs[1].status, JobStatus.complete);
  });
  test('notes are trimmed, bounded and survive reconstruction', () {
    final p = MemoryStore();
    final s = JobStore(p);
    expect(s.addNote('FN-1043', '  Test inspection  '), true);
    expect(s.addNote('FN-1043', '  '), false);
    expect(s.addNote('FN-1043', 'x' * 501), false);
    expect(s.addNote('missing', 'hello'), false);
    expect(JobStore(p).jobs[1].notes, ['Test inspection']);
  });
  test('reset replaces only demo content', () {
    final p = MemoryStore();
    final s = JobStore(p);
    s.transition('FN-1043', JobStatus.complete);
    s.addNote('FN-1043', 'test');
    s.reset();
    final restored = JobStore(p);
    expect(restored.jobs[1].status, JobStatus.scheduled);
    expect(restored.jobs[1].notes, isEmpty);
    expect(restored.jobs.first.notes.length, 1);
  });
  test('malformed storage recovers safely', () {
    final p = MemoryStore()..value = 'not JSON';
    final s = JobStore(p);
    expect(s.jobs.length, 5);
    expect(s.persistent, false);
    s.transition('FN-1043', JobStatus.active);
    expect(s.persistent, true);
  });
  test('unsupported schema and invalid fields do not poison samples', () {
    final p = MemoryStore()..value = '{"version":2,"jobs":{}}';
    expect(JobStore(p).jobs.length, 5);
    p.value =
        '{"version":1,"jobs":{"FN-1043":{"status":"bogus","notes":[42]}}}';
    final s = JobStore(p);
    expect(s.jobs[1].status, JobStatus.scheduled);
    expect(s.jobs[1].notes, isEmpty);
  });
  test('unavailable browser storage keeps app usable with warning', () {
    final s = JobStore(BrokenStore());
    expect(s.persistent, false);
    s.transition('FN-1043', JobStatus.active);
    expect(s.jobs[1].status, JobStatus.active);
    expect(s.persistent, false);
  });
  test('notes cap at 50 entries', () {
    final s = JobStore(MemoryStore());
    for (var i = 0; i < 50; i++) {
      expect(s.addNote('FN-1043', 'Note $i'), true);
    }
    expect(s.addNote('FN-1043', 'Overflow'), false);
  });
}
