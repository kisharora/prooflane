import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fieldnote_demo/main.dart';
import 'package:fieldnote_demo/job_store.dart';

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    final loader = FontLoader("FieldnoteSans")
      ..addFont(rootBundle.load("assets/fonts/Roboto-Regular.ttf"))
      ..addFont(rootBundle.load("assets/fonts/Roboto-Bold.ttf"));
    await loader.load();
    final icons = FontLoader("MaterialIcons")
      ..addFont(rootBundle.load("fonts/MaterialIcons-Regular.otf"));
    await icons.load();
  });
  testWidgets('mobile layout, search and detail status transition',
      (tester) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final s = JobStore(MemoryStore());
    await tester.pumpWidget(FieldnoteApp(store: s));
    await tester.pumpAndSettle();
    expect(find.text('FLUTTER DEMO'), findsOneWidget);
    await expectLater(
        find.byType(Scaffold).first, matchesGoldenFile('goldens/mobile.png'));
    expect(tester.takeException(), isNull);
    await tester.enterText(find.byType(TextField).first, 'Cedar');
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(find.text('A brighter welcome'), 250,
        scrollable: find.byType(Scrollable).first);
    await tester.tap(find.text('A brighter welcome'));
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(find.text('Start this job'), 200,
        scrollable: find
            .descendant(
                of: find.byType(JobDetail), matching: find.byType(Scrollable))
            .first);
    await tester.tap(find.text('Start this job'));
    await tester.pumpAndSettle();
    expect(s.jobs[1].status, JobStatus.active);
    expect(tester.takeException(), isNull);
  });
  testWidgets('wide layout renders a selected detail panel', (tester) async {
    tester.view.physicalSize = const Size(1440, 1000);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(FieldnoteApp(store: JobStore(MemoryStore())));
    await tester.pumpAndSettle();
    expect(find.text('JOB DETAILS'), findsOneWidget);
    await expectLater(
        find.byType(Scaffold).first, matchesGoldenFile('goldens/desktop.png'));
    expect(find.text('THE DAILY LINEUP'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  for (final size in [
    const Size(320, 720),
    const Size(768, 1024),
    const Size(1060, 800)
  ]) {
    testWidgets('responsive layout ${size.width}', (tester) async {
      tester.view.physicalSize = size;
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(FieldnoteApp(store: JobStore(MemoryStore())));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    });
  }
}
