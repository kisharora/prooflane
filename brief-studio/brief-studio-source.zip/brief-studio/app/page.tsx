import BriefStudio from "./studio";
export default function Page() {
  return <BriefStudio />;
}
