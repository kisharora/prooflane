"use client";
import { useEffect, useRef, useState } from "react";
import {
  Brief,
  Errors,
  CONSTRAINTS,
  INTEGRATIONS,
  PLATFORMS,
  STORAGE_KEY,
  TYPES,
  emptyBrief,
  exampleBrief,
  exportJSON,
  exportMarkdown,
  filename,
  parseSaved,
  validate,
} from "../lib/brief";
const steps = [
  { name: "The foundation", detail: "Project & platform" },
  { name: "The purpose", detail: "People & outcomes" },
  { name: "The boundaries", detail: "Scope & constraints" },
  { name: "The handoff", detail: "Review & export" },
];
function Icon({
  type = "arrow",
}: {
  type?: "arrow" | "file" | "lock" | "check" | "download";
}) {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {type === "file" ? (
        <>
          <path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z" />
          <path d="M14 3v5h5M9 12h6m-6 4h6" />
        </>
      ) : type === "lock" ? (
        <>
          <rect x="5" y="10" width="14" height="11" rx="2" />
          <path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v3" />
        </>
      ) : type === "check" ? (
        <path d="m5 12 4 4L19 6" />
      ) : type === "download" ? (
        <>
          <path d="M12 3v12m-5-5 5 5 5-5M5 17v4h14v-4" />
        </>
      ) : (
        <path d="M4 12h16m-6-6 6 6-6 6" />
      )}
    </svg>
  );
}
export default function BriefStudio() {
  const [brief, setBrief] = useState<Brief>(emptyBrief);
  const [step, setStep] = useState(0);
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState("");
  const [saved, setSaved] = useState("");
  const [ready, setReady] = useState(false);
  const heading = useRef<HTMLHeadingElement>(null);
  const firstRender = useRef(true);
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = parseSaved(raw);
        if (parsed) {
          setBrief(parsed);
          setSaved(JSON.stringify(parsed));
          setStatus("Your saved brief is ready.");
        } else
          setStatus(
            "The saved draft could not be read. Start fresh or reset to remove it.",
          );
      }
    } catch {
      setStatus(
        "Local storage is unavailable. You can still create and export a brief.",
      );
    }
    setReady(true);
  }, []);
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    heading.current?.focus();
  }, [step]);
  const dirty =
    JSON.stringify(brief) !== (saved || JSON.stringify(emptyBrief()));
  useEffect(() => {
    const guard = (e: BeforeUnloadEvent) => {
      if (dirty) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", guard);
    return () => window.removeEventListener("beforeunload", guard);
  }, [dirty]);
  function update<K extends keyof Brief>(key: K, value: Brief[K]) {
    setBrief((b) => ({ ...b, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
    setStatus("");
  }
  function go(target: number) {
    if (target > step) {
      const nextErrors = validate(brief, target - 1);
      setErrors(nextErrors);
      if (Object.keys(nextErrors).length) {
        setStatus("A few details are missing. Check the highlighted fields.");
        const key = Object.keys(nextErrors)[0];
        const errorStep = ["name", "type", "platform"].includes(key)
          ? 0
          : ["audience", "goals"].includes(key)
            ? 1
            : 2;
        setStep(errorStep);
        setTimeout(() => document.getElementById(key)?.focus(), 0);
        return;
      }
    }
    setErrors({});
    setStep(target);
    setStatus("");
  }
  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(brief));
      setSaved(JSON.stringify(brief));
      setStatus("Saved on this browser. You can come back to this draft.");
    } catch {
      setStatus(
        "Could not save locally. Browser storage may be blocked or full. Export your brief to keep a copy.",
      );
    }
  }
  function loadExample() {
    if (
      dirty &&
      !window.confirm(
        "Replace your current unsaved changes with the synthetic example?",
      )
    )
      return;
    setBrief(exampleBrief());
    setStep(0);
    setErrors({});
    setStatus(
      "Synthetic example loaded. These project details are fictional. Save locally to keep this draft.",
    );
  }
  function reset() {
    if (
      !window.confirm(
        "Reset this brief and remove its saved copy from this browser? This cannot be undone.",
      )
    )
      return;
    try {
      localStorage.removeItem(STORAGE_KEY);
      setBrief(emptyBrief());
      setSaved("");
      setStep(0);
      setErrors({});
      setStatus("Brief reset. The saved local copy was removed.");
    } catch {
      setStatus(
        "Reset could not remove the saved copy because storage is unavailable. Your current draft has been kept.",
      );
    }
  }
  function download(extension: "json" | "md") {
    const nextErrors = validate(brief);
    if (Object.keys(nextErrors).length) {
      setErrors(nextErrors);
      setStatus("Complete the required fields before exporting.");
      setTimeout(
        () => document.getElementById(Object.keys(nextErrors)[0])?.focus(),
        0,
      );
      return;
    }
    try {
      const blob = new Blob(
        [extension === "json" ? exportJSON(brief) : exportMarkdown(brief)],
        {
          type:
            extension === "json"
              ? "application/json;charset=utf-8"
              : "text/markdown;charset=utf-8",
        },
      );
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = filename(brief.name, extension);
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setStatus(
        `${extension === "json" ? "JSON" : "Markdown"} download started. Check your browser’s downloads.`,
      );
    } catch {
      setStatus(
        "The download could not start. Try another browser or copy your brief details manually.",
      );
    }
  }
  function field(
    key:
      | "name"
      | "audience"
      | "goals"
      | "success"
      | "requirements"
      | "outOfScope"
      | "notes",
    label: string,
    hint: string,
    max: number,
    placeholder: string,
    required = false,
    rows = 3,
  ) {
    const described = `${key}-hint${errors[key] ? ` ${key}-error` : ""}`;
    return (
      <div className={`field ${errors[key] ? "invalid" : ""}`}>
        <label htmlFor={key}>
          {label}
          {required ? (
            <span className="required">Required</span>
          ) : (
            <span className="optional">Optional</span>
          )}
        </label>
        <p className="hint" id={`${key}-hint`}>
          {hint}
        </p>
        {key === "name" ? (
          <input
            id={key}
            value={brief[key]}
            maxLength={max}
            onChange={(e) => update(key, e.target.value)}
            placeholder={placeholder}
            aria-describedby={described}
            aria-invalid={!!errors[key]}
            required={required}
          />
        ) : (
          <textarea
            id={key}
            rows={rows}
            value={brief[key]}
            maxLength={max}
            onChange={(e) => update(key, e.target.value)}
            placeholder={placeholder}
            aria-describedby={described}
            aria-invalid={!!errors[key]}
            required={required}
          />
        )}
        <div className="field-foot">
          {errors[key] ? (
            <span id={`${key}-error`} className="error">
              {errors[key]}
            </span>
          ) : (
            <span />
          )}
          <span>
            {brief[key].length.toLocaleString()} / {max.toLocaleString()}
          </span>
        </div>
      </div>
    );
  }
  function options(
    key: "integrations" | "constraints",
    values: readonly string[],
    label: string,
    hint: string,
  ) {
    return (
      <fieldset className="options">
        <legend>
          {label} <span className="optional">Optional</span>
        </legend>
        <p className="hint">{hint}</p>
        <div className="chips">
          {values.map((value) => (
            <label
              key={value}
              className={`chip ${brief[key].includes(value) ? "selected" : ""}`}
            >
              <input
                type="checkbox"
                checked={brief[key].includes(value)}
                onChange={(e) =>
                  update(
                    key,
                    e.target.checked
                      ? [...brief[key], value]
                      : brief[key].filter((v) => v !== value),
                  )
                }
              />
              <span>{value}</span>
            </label>
          ))}
        </div>
      </fieldset>
    );
  }
  const filled = [
    brief.name.trim().length >= 3,
    brief.audience.trim().length >= 5 && brief.goals.trim().length >= 20,
    brief.requirements.trim().length >= 10,
  ].filter(Boolean).length;
  return (
    <>
      <a href="#workspace" className="skip-link">
        Skip to brief editor
      </a>
      <header className="topbar">
        <a
          className="brand"
          href="/prooflane/brief-studio/"
          aria-label="Brief Studio home"
        >
          <span className="brand-mark">
            <Icon type="file" />
          </span>
          brief<span className="brand-light">studio</span>
          <span className="demo-label">DEMO</span>
        </a>
        <div className="top-actions">
          <span className="local-tag">
            <span /> Local-only workspace
          </span>
          <a className="portfolio-link" href="/prooflane/portfolio/">
            Portfolio <span aria-hidden="true">↗</span>
          </a>
        </div>
      </header>
      <div className="shell">
        <aside className="sidebar">
          <div>
            <p className="eyebrow">FROM IDEA TO HANDOFF</p>
            <h1>A clearer start.</h1>
            <p className="sidebar-intro">
              Turn the first conversation into a brief worth building from.
            </p>
          </div>
          <nav aria-label="Brief sections">
            <ol className="steps">
              {steps.map((item, i) => (
                <li key={item.name}>
                  <button
                    className={`step ${step === i ? "active" : ""}`}
                    aria-current={step === i ? "step" : undefined}
                    onClick={() => go(i)}
                  >
                    <span className="step-num">
                      {i < step ? <Icon type="check" /> : `0${i + 1}`}
                    </span>
                    <span>
                      <strong>{item.name}</strong>
                      <small>{item.detail}</small>
                    </span>
                    {step === i && <span className="step-dot" />}
                  </button>
                </li>
              ))}
            </ol>
          </nav>
          <div className="sidebar-bottom">
            <div className="privacy">
              <Icon type="lock" />
              <div>
                <strong>Your ideas stay here.</strong>
                <p>
                  Brief content is kept in this tab unless you save it in this
                  browser or export a file. No accounts, analytics, or AI
                  processing. The static host receives normal page requests.
                </p>
              </div>
            </div>
            <button className="text-button" onClick={loadExample}>
              Try a synthetic example <span aria-hidden="true">↗</span>
            </button>
            <p className="built-with">
              Built with Next.js + React + TypeScript
            </p>
          </div>
        </aside>
        <main id="workspace" className="workspace">
          <div className="workspace-bar">
            <div className="breadcrumb">
              WORKSPACE <span>/</span> NEW PROJECT BRIEF
            </div>
            <span className={`save-state ${dirty ? "unsaved" : ""}`}>
              <span />
              {!ready
                ? "Opening workspace…"
                : dirty
                  ? "Unsaved changes"
                  : saved
                    ? "Saved in this browser"
                    : "Fresh draft"}
            </span>
          </div>
          <div className="editor-grid">
            <section className="editor" aria-labelledby="section-title">
              <div className="section-top">
                <p className="eyebrow">STEP 0{step + 1} / 04</p>
                <span className="small-label">
                  {step === 3
                    ? "Make it yours. Then take it with you."
                    : "A little clarity goes a long way."}
                </span>
              </div>
              <h2 id="section-title" ref={heading} tabIndex={-1}>
                {
                  [
                    "First, the essentials.",
                    "Build for a real need.",
                    "Draw a useful boundary.",
                    "Your brief, ready to go.",
                  ][step]
                }
              </h2>
              <p className="section-description">
                {
                  [
                    "Name the project and choose a starting point. It’s okay if the details evolve.",
                    "Who is this for, and what should be better when it exists?",
                    "Define the must-haves, the edges, and the systems it needs to work with.",
                    "Review and edit the details below. Exports are generated here in your browser.",
                  ][step]
                }
              </p>
              {brief.synthetic && (
                <div className="example-notice">
                  <span className="example-dot" /> Synthetic example · Fictional
                  project details
                </div>
              )}
              <div className="notice" role="status" aria-live="polite">
                {status}
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (step < 3) go(step + 1);
                  else save();
                }}
                noValidate
              >
                {(step === 0 || step === 3) && (
                  <>
                    {step === 3 && (
                      <h3 className="review-section">01 / Foundation</h3>
                    )}
                    {field(
                      "name",
                      "Project name",
                      "A working name is all you need.",
                      80,
                      "e.g. Neighborhood tool library",
                      true,
                    )}
                    <fieldset className="project-types">
                      <legend>What are you building?</legend>
                      <div className="type-grid">
                        {TYPES.map((type, i) => (
                          <label
                            key={type}
                            className={`type-card ${brief.type === type ? "selected" : ""}`}
                          >
                            <input
                              type="radio"
                              name="project-type"
                              value={type}
                              checked={brief.type === type}
                              onChange={() => update("type", type)}
                            />
                            <span className="type-symbol" aria-hidden="true">
                              {["◫", "▤", "▯", "▦"][i]}
                            </span>
                            <strong>{type}</strong>
                            <small>
                              {
                                [
                                  "An interactive digital product",
                                  "A content-led web presence",
                                  "An experience for small screens",
                                  "A better team workflow",
                                ][i]
                              }
                            </small>
                          </label>
                        ))}
                      </div>
                    </fieldset>
                    <div className="field">
                      <label htmlFor="platform">
                        Preferred platform
                        <span className="optional">Starting point</span>
                      </label>
                      <p id="platform-hint" className="hint">
                        A preference for discussion, not a technical commitment.
                      </p>
                      <select
                        id="platform"
                        value={brief.platform}
                        onChange={(e) => update("platform", e.target.value)}
                        aria-describedby="platform-hint"
                      >
                        {PLATFORMS.map((platform) => (
                          <option key={platform}>{platform}</option>
                        ))}
                      </select>
                    </div>
                  </>
                )}
                {(step === 1 || step === 3) && (
                  <>
                    {step === 3 && (
                      <h3 className="review-section">02 / Purpose</h3>
                    )}
                    {field(
                      "audience",
                      "Who will use it?",
                      "Describe the people and the situation they’re in.",
                      500,
                      "e.g. Residents looking for a tool they only need once.",
                      true,
                      2,
                    )}
                    {field(
                      "goals",
                      "What should this project achieve?",
                      "Focus on the problem and the outcome, rather than a feature list.",
                      2000,
                      "What is difficult today? What should become easier?",
                      true,
                      4,
                    )}
                    {field(
                      "success",
                      "What would success look like?",
                      "Make the outcome observable. No promised metrics needed.",
                      1000,
                      "e.g. A visitor can find a suitable tool without calling the library.",
                      false,
                    )}
                  </>
                )}
                {(step === 2 || step === 3) && (
                  <>
                    {step === 3 && (
                      <h3 className="review-section">03 / Boundaries</h3>
                    )}
                    {field(
                      "requirements",
                      "Must-have requirements",
                      "One requirement per line makes the handoff easier to scan.",
                      3000,
                      "What must someone be able to do?",
                      true,
                      5,
                    )}
                    {field(
                      "outOfScope",
                      "Out of scope",
                      "What should this version deliberately leave out?",
                      1500,
                      "e.g. Online payments, identity verification",
                      false,
                    )}
                    {options(
                      "integrations",
                      INTEGRATIONS,
                      "Connections & integrations",
                      "Select the systems or services to discuss. No connection is made.",
                    )}
                    {options(
                      "constraints",
                      CONSTRAINTS,
                      "Design & technical constraints",
                      "Choose what should shape the solution.",
                    )}
                  </>
                )}
                {step === 3 && (
                  <>
                    {field(
                      "notes",
                      "Open questions & notes",
                      "Capture decisions that still need a conversation.",
                      2000,
                      "What needs clarification before work begins?",
                      false,
                    )}
                    <div className="export-card">
                      <div className="export-icon">
                        <Icon type="download" />
                      </div>
                      <h3>Take your brief with you.</h3>
                      <p>
                        Markdown for people. JSON for tools. Both contain your
                        current edits.
                      </p>
                      <div className="export-buttons">
                        <button
                          type="button"
                          className="primary"
                          onClick={() => download("md")}
                        >
                          <Icon type="download" /> Export Markdown
                        </button>
                        <button
                          type="button"
                          className="secondary"
                          onClick={() => download("json")}
                        >
                          Export JSON
                        </button>
                      </div>
                      <small>
                        This brief is a planning document, not a quote or
                        delivery commitment.
                      </small>
                    </div>
                  </>
                )}
                <div className="editor-footer">
                  <button
                    type="button"
                    className="back"
                    onClick={() => go(step - 1)}
                    disabled={step === 0}
                  >
                    ← Back
                  </button>
                  <button type="submit" className="primary">
                    {step === 3
                      ? "Save locally"
                      : step === 2
                        ? "Review brief"
                        : "Continue"}
                    {step < 3 && <Icon />}
                  </button>
                </div>
              </form>
            </section>
            <aside className="outline" aria-label="Live brief outline">
              <div className="outline-heading">
                <Icon type="file" />
                <span>YOUR BRIEF</span>
                <span className="live">
                  <span /> LIVE
                </span>
              </div>
              <div className="outline-body">
                <span className="document-tag">PROJECT OVERVIEW</span>
                <h3>{brief.name.trim() || "Untitled project"}</h3>
                <div className="outline-rule" />
                <dl>
                  <dt>PROJECT TYPE</dt>
                  <dd>{brief.type}</dd>
                  <dt>PLATFORM</dt>
                  <dd>{brief.platform}</dd>
                  <dt>AUDIENCE</dt>
                  <dd className={!brief.audience ? "placeholder" : ""}>
                    {brief.audience || "Who are we building for?"}
                  </dd>
                  <dt>THE GOAL</dt>
                  <dd className={!brief.goals ? "placeholder" : ""}>
                    {brief.goals || "What should get better?"}
                  </dd>
                </dl>
                {brief.requirements && (
                  <div className="outline-scope">
                    <span className="document-tag">REQUIREMENTS</span>
                    <ul>
                      {brief.requirements
                        .split("\n")
                        .map((s) => s.trim())
                        .filter(Boolean)
                        .slice(0, 4)
                        .map((r, i) => (
                          <li key={i}>{r}</li>
                        ))}
                    </ul>
                    {brief.requirements.split("\n").filter((s) => s.trim())
                      .length > 4 && <small>More in your full brief</small>}
                  </div>
                )}
                {brief.constraints.length > 0 && (
                  <div className="mini-tags">
                    {brief.constraints.map((c) => (
                      <span key={c}>{c}</span>
                    ))}
                  </div>
                )}
                <div className="completeness">
                  <div>
                    <span>Foundations covered</span>
                    <strong>{filled} / 3</strong>
                  </div>
                  <div className="progress-track">
                    <span style={{ width: `${(filled / 3) * 100}%` }} />
                  </div>
                  <small>A focused brief beats a long one.</small>
                </div>
              </div>
              <div className="outline-tip">
                <span aria-hidden="true">✳</span>
                <p>
                  {
                    [
                      "Start with what you know. You can change every detail before exporting.",
                      "Good goals describe a change for people, not just a list of screens.",
                      "Saying what’s out of scope is just as useful as saying what’s in.",
                      "The best handoff leaves room for the right questions.",
                    ][step]
                  }
                </p>
              </div>
            </aside>
          </div>
          <p className="mobile-privacy">
            <Icon type="lock" /> Local-only: no accounts, analytics, or AI
            processing. Brief content stays in this tab unless you save it in
            this browser or export it. The static host receives normal page
            requests.
          </p>
          <footer className="workspace-footer">
            <span>Clarity before complexity.</span>
            <div>
              <a
                href="/prooflane/brief-studio/brief-studio-source.zip"
                download
              >
                Source (ZIP)
              </a>
              <span aria-hidden="true">·</span>
              <button onClick={save} disabled={!ready}>
                Save locally
              </button>
              <span aria-hidden="true">·</span>
              <button onClick={reset} disabled={!ready}>
                Reset brief
              </button>
            </div>
          </footer>
        </main>
      </div>
    </>
  );
}
