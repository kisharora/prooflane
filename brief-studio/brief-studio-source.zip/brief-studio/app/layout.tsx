import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Brief Studio · A clearer start",
  description:
    "A local-only project brief builder. Shape your goals, scope and constraints, then export a structured handoff.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
