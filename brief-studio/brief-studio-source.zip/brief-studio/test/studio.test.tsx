import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import { act } from "react";
import { STORAGE_KEY, exampleBrief } from "../lib/brief";
const dom = new JSDOM(
  '<!doctype html><html><body><div id="root"></div></body></html>',
  { url: "https://example.test/prooflane/brief-studio/" },
);
Object.assign(globalThis, {
  window: dom.window,
  document: dom.window.document,
  localStorage: dom.window.localStorage,
  HTMLElement: dom.window.HTMLElement,
  IS_REACT_ACT_ENVIRONMENT: true,
});
const { createRoot } = await import("react-dom/client");
const { default: Studio } = await import("../app/studio");
let root: ReturnType<typeof createRoot>;
const button = (text: string) =>
  [...document.querySelectorAll("button")].find(
    (b) => b.textContent?.trim() === text,
  )!;
async function click(element: Element) {
  assert.ok(element);
  await act(async () => {
    element.dispatchEvent(
      new dom.window.MouseEvent("click", { bubbles: true }),
    );
  });
}
async function mount(raw?: string) {
  localStorage.clear();
  if (raw) localStorage.setItem(STORAGE_KEY, raw);
  root = createRoot(document.getElementById("root")!);
  await act(async () => {
    root.render(<Studio />);
  });
}
async function unmount() {
  await act(async () => root.unmount());
}
async function input(id: string, value: string) {
  const element = document.getElementById(id) as HTMLInputElement;
  const prototype =
    element.tagName === "TEXTAREA"
      ? dom.window.HTMLTextAreaElement.prototype
      : dom.window.HTMLInputElement.prototype;
  await act(async () => {
    Object.getOwnPropertyDescriptor(prototype, "value")!.set!.call(
      element,
      value,
    );
    element.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  });
}
test("empty next step is blocked; user edits reach the next step and live outline", async () => {
  await mount();
  await click(button("Continue"));
  assert.match(document.body.textContent!, /Give the project a name/);
  await input("name", "A new project");
  await click(button("Continue"));
  assert.match(
    document.getElementById("section-title")!.textContent!,
    /Build for a real need/,
  );
  assert.match(
    document.querySelector(".outline")!.textContent!,
    /A new project/,
  );
  await unmount();
});
test("example supports step flow, checkbox edits, review edits, and both downloads", async () => {
  await mount();
  await click(button("Try a synthetic example ↗"));
  await click(button("Continue"));
  await click(button("Continue"));
  const choice = [...document.querySelectorAll("label.chip")]
    .find((e) => e.textContent === "Calendar")!
    .querySelector("input")!;
  await click(choice);
  await click(button("Review brief"));
  assert.match(
    document.getElementById("section-title")!.textContent!,
    /Your brief, ready to go/,
  );
  assert.ok(document.querySelector("label.chip input:checked"));
  await input("name", "Edited fictional project");
  const blobs: Blob[] = [];
  const downloads: string[] = [];
  URL.createObjectURL = (blob: Blob) => {
    blobs.push(blob);
    return "blob:test";
  };
  URL.revokeObjectURL = () => {};
  dom.window.HTMLAnchorElement.prototype.click = function () {
    downloads.push(this.download);
  };
  await click(button("Export JSON"));
  await click(button("Export Markdown"));
  assert.deepEqual(downloads, [
    "edited-fictional-project-brief.json",
    "edited-fictional-project-brief.md",
  ]);
  const json = JSON.parse(await blobs[0].text());
  assert.equal(json.name, "Edited fictional project");
  assert.ok(json.integrations.includes("Calendar"));
  assert.match(await blobs[1].text(), /Synthetic example/);
  await unmount();
});
test("save restores draft; cancel and confirm reset have distinct outcomes", async () => {
  await mount(JSON.stringify(exampleBrief()));
  await input("name", "Locally edited");
  await click(button("Save locally"));
  assert.equal(
    JSON.parse(localStorage.getItem(STORAGE_KEY)!).name,
    "Locally edited",
  );
  dom.window.confirm = () => false;
  await click(button("Reset brief"));
  assert.equal(
    (document.getElementById("name") as HTMLInputElement).value,
    "Locally edited",
  );
  dom.window.confirm = () => true;
  await click(button("Reset brief"));
  assert.equal(localStorage.getItem(STORAGE_KEY), null);
  assert.equal((document.getElementById("name") as HTMLInputElement).value, "");
  await unmount();
});
test("corrupt drafts fail safely and rendered text never becomes executable markup", async () => {
  await mount("{broken");
  assert.match(document.body.textContent!, /saved draft could not be read/);
  await unmount();
  await mount(
    JSON.stringify({ ...exampleBrief(), name: "<img src=x onerror=alert(1)>" }),
  );
  assert.equal(document.querySelectorAll("img").length, 0);
  assert.ok(document.querySelector(".outline")!.textContent!.includes("<img"));
  await unmount();
});
test("local storage failures are surfaced without losing current draft", async () => {
  await mount();
  await click(button("Try a synthetic example ↗"));
  const original = dom.window.Storage.prototype.setItem;
  dom.window.Storage.prototype.setItem = () => {
    throw new Error("blocked");
  };
  await click(button("Save locally"));
  assert.match(document.body.textContent!, /Could not save locally/);
  assert.equal(
    (document.getElementById("name") as HTMLInputElement).value,
    exampleBrief().name,
  );
  dom.window.Storage.prototype.setItem = original;
  await unmount();
});
