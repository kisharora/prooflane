import test from "node:test";
import assert from "node:assert/strict";
import {
  emptyBrief,
  exampleBrief,
  exportJSON,
  exportMarkdown,
  filename,
  parseSaved,
  validate,
} from "../lib/brief";
test("empty draft validates only fields in reached sections", () => {
  assert.deepEqual(Object.keys(validate(emptyBrief(), 0)), ["name"]);
  assert.deepEqual(Object.keys(validate(emptyBrief(), 1)), [
    "name",
    "audience",
    "goals",
  ]);
  assert.deepEqual(Object.keys(validate(emptyBrief())), [
    "name",
    "audience",
    "goals",
    "requirements",
  ]);
});
test("synthetic example is complete and explicit", () => {
  const b = exampleBrief();
  assert.deepEqual(validate(b), {});
  assert.equal(b.synthetic, true);
  assert.match(exportMarkdown(b), /Synthetic example/);
});
test("validation rejects whitespace, unsupported choices and overlong values", () => {
  const b = {
    ...exampleBrief(),
    name: "  ",
    goals: " ".repeat(22),
    requirements: " ".repeat(12),
    platform: "invalid",
  };
  assert.ok(validate(b).name);
  assert.ok(validate(b).goals);
  assert.ok(validate(b).requirements);
  assert.ok(validate(b).platform);
  assert.ok(validate({ ...exampleBrief(), name: "a".repeat(81) }).name);
});
test("saved schema rejects corrupt, incompatible and injected data", () => {
  for (const raw of [
    "bad",
    "null",
    "[]",
    "{}",
    JSON.stringify({ ...exampleBrief(), version: 2 }),
    JSON.stringify({ ...exampleBrief(), goals: 4 }),
    JSON.stringify({ ...exampleBrief(), integrations: ["untrusted"] }),
    JSON.stringify({ ...exampleBrief(), constraints: null }),
  ])
    assert.equal(parseSaved(raw), null);
  const b = exampleBrief();
  assert.deepEqual(
    parseSaved(JSON.stringify({ ...b, unwanted: "discard me" })),
    b,
  );
});
test("partial drafts round-trip; exports preserve edits, arrays and Unicode", () => {
  const b = {
    ...emptyBrief(),
    name: " Café ☕ ",
    goals: "Edited goal",
    integrations: ["Search"],
  };
  assert.deepEqual(parseSaved(JSON.stringify(b)), b);
  const out = JSON.parse(exportJSON(b));
  assert.equal(out.name, "Café ☕");
  assert.equal(out.goals, "Edited goal");
  assert.deepEqual(out.integrations, ["Search"]);
});
test("Markdown escapes HTML and link syntax, includes all sections", () => {
  const b = {
    ...exampleBrief(),
    name: "<img src=x onerror=alert(1)>",
    goals:
      "[click](javascript:alert(1))\n# unexpected heading\n<script>bad()</script>",
  };
  const result = exportMarkdown(b);
  assert.ok(!result.includes("<script>"));
  assert.ok(!result.includes("\n# unexpected"));
  assert.ok(!result.includes("[click]"));
  for (const title of [
    "Audience",
    "Goals",
    "Success criteria",
    "Requirements",
    "Out of scope",
    "Integrations",
    "Constraints",
    "Open questions & notes",
  ])
    assert.ok(result.includes(`## ${title}`));
});
test("export filenames remain bounded and cannot contain paths", () => {
  assert.equal(
    filename("../../A Fine Project", "json"),
    "a-fine-project-brief.json",
  );
  assert.equal(filename("☕", "md"), "project-brief.md");
  assert.equal(filename("a".repeat(100), "md").length, 69);
});
