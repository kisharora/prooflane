"""Package only explicitly allowed demo source and static output (Python standard library)."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parent.parent
out = root / "out"
if not (out / "index.html").is_file():
    raise SystemExit("Run npm run build first.")

# GitHub Pages needs .nojekyll in its repository root as well.
(out / ".nojekyll").touch()
source_zip = out / "brief-studio-source.zip"
source_dirs = ["app", "lib", "test", "scripts", "public"]
source_files = ["package.json", "package-lock.json", "next.config.ts", "next-env.d.ts", "tsconfig.json", ".gitignore", "README.md"]
with zipfile.ZipFile(source_zip, "w", zipfile.ZIP_DEFLATED) as archive:
    for name in source_files:
        archive.write(root / name, f"brief-studio/{name}")
    for name in source_dirs:
        for path in sorted((root / name).rglob("*")):
            if path.is_file():
                archive.write(path, "brief-studio/" + str(path.relative_to(root)))

# Validate Next.js assets against the configured static deployment path.
html = (out / "index.html").read_text()
refs = set(re.findall(r'(?:src|href)="(/prooflane/brief-studio/[^"?#]+)', html))
missing = [ref for ref in refs if not (out / ref.removeprefix("/prooflane/brief-studio/")).exists()]
if missing:
    raise SystemExit(f"Missing assets: {missing}")

destination = root.parent / "deliverables"
destination.mkdir(exist_ok=True)
static_zip = destination / "brief-studio-static.zip"
with zipfile.ZipFile(static_zip, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(out.rglob("*")):
        if path.is_file():
            archive.write(path, "brief-studio/" + str(path.relative_to(out)))
(destination / "brief-studio-source.zip").write_bytes(source_zip.read_bytes())
manifest = {"basePath": "/prooflane/brief-studio/", "framework": "Next.js static export + React + TypeScript", "files": []}
for path in sorted(out.rglob("*")):
    if path.is_file():
        manifest["files"].append({"path": str(path.relative_to(out)), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
(destination / "brief-studio-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(f"Validated {len(refs)} referenced assets; packaged {len(manifest['files'])} static files.")
print(f"Static: {static_zip} ({static_zip.stat().st_size:,} bytes)")
print(f"Source: {source_zip} ({source_zip.stat().st_size:,} bytes)")
