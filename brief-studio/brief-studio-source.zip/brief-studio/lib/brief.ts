export const STORAGE_KEY = "brief-studio:v1";
export const TYPES = [
  "Web application",
  "Website",
  "Mobile companion",
  "Internal tool",
] as const;
export const PLATFORMS = [
  "React / Next.js",
  "WordPress",
  "Flutter",
  "Open to guidance",
] as const;
export const INTEGRATIONS = [
  "Content management",
  "Email notifications",
  "Search",
  "Maps",
  "Calendar",
  "Existing API",
] as const;
export const CONSTRAINTS = [
  "Mobile-first",
  "Keyboard accessible",
  "Low-bandwidth friendly",
  "Works offline",
  "Existing brand system",
  "Multilingual",
] as const;
export type Brief = {
  version: 1;
  synthetic: boolean;
  name: string;
  type: string;
  platform: string;
  audience: string;
  goals: string;
  success: string;
  requirements: string;
  outOfScope: string;
  integrations: string[];
  constraints: string[];
  notes: string;
};
export type Errors = Partial<Record<keyof Brief, string>>;
export const emptyBrief = (): Brief => ({
  version: 1,
  synthetic: false,
  name: "",
  type: TYPES[0],
  platform: PLATFORMS[0],
  audience: "",
  goals: "",
  success: "",
  requirements: "",
  outOfScope: "",
  integrations: [],
  constraints: [],
  notes: "",
});
export const exampleBrief = (): Brief => ({
  ...emptyBrief(),
  synthetic: true,
  name: "Trailside community library",
  type: "Web application",
  platform: "React / Next.js",
  audience: "Local residents browsing a fictional community tool library.",
  goals:
    "Help residents discover useful tools, understand borrowing requirements, and prepare a request without calling the library.",
  success:
    "A first-time visitor can find a suitable tool and understand the next step using only a keyboard.",
  requirements:
    "Browse a catalog by category\nFilter by availability\nView care instructions and borrowing requirements\nPrepare a borrowing request for staff review",
  outOfScope:
    "Online payments\nMember identity verification\nAutomated approval of borrowing requests",
  integrations: ["Content management", "Search"],
  constraints: [
    "Mobile-first",
    "Keyboard accessible",
    "Low-bandwidth friendly",
  ],
  notes:
    "Synthetic portfolio example. All names and project details are fictional. Availability data would need a confirmed source before implementation.",
});
const limits: Record<string, number> = {
  name: 80,
  audience: 500,
  goals: 2000,
  success: 1000,
  requirements: 3000,
  outOfScope: 1500,
  notes: 2000,
};
export function validate(brief: Brief, throughStep = 3): Errors {
  const errors: Errors = {};
  if (brief.name.trim().length < 3)
    errors.name = "Give the project a name of at least 3 characters.";
  if (!TYPES.includes(brief.type as (typeof TYPES)[number]))
    errors.type = "Choose a project type.";
  if (!PLATFORMS.includes(brief.platform as (typeof PLATFORMS)[number]))
    errors.platform = "Choose a platform.";
  if (throughStep >= 1) {
    if (brief.audience.trim().length < 5)
      errors.audience =
        "Describe who will use the project (at least 5 characters).";
    if (brief.goals.trim().length < 20)
      errors.goals =
        "Describe the problem and desired outcome (at least 20 characters).";
  }
  if (throughStep >= 2 && brief.requirements.trim().length < 10)
    errors.requirements =
      "Add at least one useful requirement (at least 10 characters).";
  for (const [key, max] of Object.entries(limits))
    if (String(brief[key as keyof Brief]).length > max)
      errors[key as keyof Brief] = `Keep this field to ${max} characters.`;
  return errors;
}
export function parseSaved(raw: string): Brief | null {
  try {
    const x = JSON.parse(raw);
    if (!x || x.version !== 1 || typeof x.synthetic !== "boolean") return null;
    for (const key of Object.keys(emptyBrief())) {
      if (["version", "synthetic", "integrations", "constraints"].includes(key))
        continue;
      if (typeof x[key] !== "string") return null;
      if (x[key].length > (limits[key] ?? 100)) return null;
    }
    if (!TYPES.includes(x.type) || !PLATFORMS.includes(x.platform)) return null;
    if (
      !Array.isArray(x.integrations) ||
      !x.integrations.every(
        (v: unknown) =>
          typeof v === "string" &&
          INTEGRATIONS.includes(v as (typeof INTEGRATIONS)[number]),
      )
    )
      return null;
    if (
      !Array.isArray(x.constraints) ||
      !x.constraints.every(
        (v: unknown) =>
          typeof v === "string" &&
          CONSTRAINTS.includes(v as (typeof CONSTRAINTS)[number]),
      )
    )
      return null;
    return Object.fromEntries(
      Object.keys(emptyBrief()).map((k) => [k, x[k]]),
    ) as Brief;
  } catch {
    return null;
  }
}
export function exportJSON(brief: Brief): string {
  return JSON.stringify({ ...brief, name: brief.name.trim() }, null, 2);
}
const md = (value: string) => value.replace(/[\\`*_{}[\]<>#|!]/g, "\\$&");
export function exportMarkdown(b: Brief): string {
  const section = (title: string, value: string) =>
    `## ${title}\n\n${value.trim() ? md(value.trim()) : "Not specified"}\n`;
  return (
    `# ${md(b.name.trim().replace(/[\r\n]+/g, " "))}\n\n${b.synthetic ? "> Synthetic example. Fictional project details.\n\n" : ""}Project type: ${md(b.type)}  \nPlatform: ${md(b.platform)}\n\n` +
    [
      section("Audience", b.audience),
      section("Goals", b.goals),
      section("Success criteria", b.success),
      section("Requirements", b.requirements),
      section("Out of scope", b.outOfScope),
      section("Integrations", b.integrations.join("\n")),
      section("Constraints", b.constraints.join("\n")),
      section("Open questions & notes", b.notes),
    ].join("\n") +
    "\n---\nPrepared with Brief Studio. A planning brief, not a quote or delivery commitment.\n"
  );
}
export function filename(name: string, extension: "json" | "md") {
  return `${
    name
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 60) || "project"
  }-brief.${extension}`;
}
