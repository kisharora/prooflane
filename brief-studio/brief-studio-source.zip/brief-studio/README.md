# Brief Studio

A real, browser-local project brief builder built with **Next.js, React and TypeScript**. This is a self-contained portfolio demonstration, not a commissioned client application.

## What it does

- Four-step, keyboard-accessible brief workflow with validation and an editable final review.
- Project type and platform selection, audience, goals, success criteria, requirements and exclusions.
- Optional integration and constraint selections; selections do not connect any services.
- A live outline that safely renders user input as text.
- JSON and escaped Markdown downloads generated in the browser.
- Explicit local save, reload restoration, unsaved-change notice, and confirmed reset.
- Clearly labeled fictional sample; it remains labeled in both exports.
- Responsive layouts and a reduced-motion preference.

## Privacy and limits

No sign-in, backend, analytics, external fonts, AI processing, API keys or payment flow. The static host receives normal page/asset requests, but this app does not send brief content to a server. Saving uses `localStorage` in the current browser; reset removes that copy. Downloads contain the current brief. Browser settings or private browsing may prevent persistence. A brief is a planning document, not a quote or delivery commitment. This demo is not an offline-installable application.

Avoid putting sensitive information in a shared browser. JSON and Markdown files should be reviewed before sharing. No real client data or private portfolio material is included.

## Development

Requires Node.js 20.9 or later and npm. Dependencies are locked in `package-lock.json`.

```sh
npm ci
npm run dev
```

Open `http://localhost:3000/prooflane/brief-studio/`.

```sh
npm run typecheck
npm test
npm run format:check
npm run build
```

The build performs a real Next.js static export into `out/`. The configured base path is `/prooflane/brief-studio/`; `out/` belongs at `brief-studio/` within the `prooflane` GitHub Pages repository. The repository root needs `.nojekyll` so GitHub Pages serves `_next` assets. No Node.js server is needed for the published app.

To create the downloadable source ZIP and a deployment ZIP, run `npm run package` (requires Python 3 for its standard-library ZIP support). It allowlists source files and validates generated asset paths. The source download is inserted into `out/` after building.

## Source map

- `app/studio.tsx`: React UI, state, browser-local persistence and download interactions.
- `app/globals.css`: responsive visual system, focus states and reduced-motion support.
- `lib/brief.ts`: typed model, schema checks, validation and export helpers.
- `test/brief.test.ts`: pure validation, storage schema and export tests.
- `test/studio.test.tsx`: actual React DOM workflow tests using jsdom.
- `next.config.ts`: static export and GitHub Pages base path.

## Verification

The automated suite covers empty and partial briefs, invalid inputs, corruption-safe restore, JSON/Markdown content and filenames, navigation gating, live React state edits, integration toggles, save, cancelled/confirmed reset, safe text rendering, and browser storage failure. It does not substitute for a real-browser visual/accessibility review or verify successful download completion on every browser.

### Public-browser QA checklist

1. Load the published URL and confirm the CSS and Next.js scripts load successfully.
2. Check desktop and 390px mobile widths for clipping and readable controls.
3. Submit the empty first step; the name error should appear and receive focus.
4. Load the synthetic example, continue through all steps and edit the project name in review.
5. Toggle integrations/constraints and check JSON and Markdown downloads contain the current edits.
6. Save locally, reload, and confirm the edits remain.
7. Cancel reset, verify no data changes, then confirm reset and reload to verify removal.
8. Tab through the interface and check visible focus, control labels and native confirmation dialogs.
9. Verify the network contains static asset requests only during editing and exporting.

## Attribution

Original fictional portfolio demo prepared for Kish Arora. The application uses open-source framework dependencies listed in `package.json`; no external visual assets are required.
